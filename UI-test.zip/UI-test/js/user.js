
$(document).on('click', '.fillter-bttn', function(event) {
    event.stopPropagation();
    if ($(this).hasClass('open_filer_wrap')) {
        $(".filter-right_panel").removeClass('open_filer_wrap');
    } else {
        $(".filter-right_panel").removeClass('open_filer_wrap');
        $('.filter-right_panel').addClass('open_filer_wrap');
    }
});
$('.filter_close').click(function() {
    $(".filter-right_panel").removeClass('open_filer_wrap');
});
$('.upload-btn').on('click', function () {
    var fileName = $("#file-upload").val();
    if (fileName) {
        $('#file-name').html($('#file-upload').val());    
    }
    else {
        alert("Please select a file to upload");
    }
});
$('.upload-btn').on('click', function(event) {
    event.stopPropagation();
    $(".filter-right_panel").removeClass('open_filer_wrap');
});